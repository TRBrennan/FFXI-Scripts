return {
    ["Glassy Thinker"]={
        ["Pain Sync"]={
            ["complete_reaction"]="facemob", 
            ["ready_reaction"]="turnaround"
        }
    }
}